def log(msg): print(f"[LOG] {msg }")

log("Starting AnalyzerAgent...")
log("AnalyzerAgent finished processing.")
