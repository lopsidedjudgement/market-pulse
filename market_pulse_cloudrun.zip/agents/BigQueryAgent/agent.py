def log(msg): print(f"[LOG] {msg }")

log("Starting BigQueryAgent...")
log("BigQueryAgent finished processing.")
