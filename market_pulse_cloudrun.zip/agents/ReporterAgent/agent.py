def log(msg): print(f"[LOG] {msg }")

log("Starting ReporterAgent...")
log("ReporterAgent finished processing.")
