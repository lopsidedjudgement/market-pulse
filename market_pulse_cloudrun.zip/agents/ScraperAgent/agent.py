def log(msg): print(f"[LOG] {msg }")

log("Starting ScraperAgent...")
log("ScraperAgent finished processing.")
