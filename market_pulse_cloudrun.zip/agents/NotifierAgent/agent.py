def log(msg): print(f"[LOG] {msg }")

log("Starting NotifierAgent...")
log("NotifierAgent finished processing.")
