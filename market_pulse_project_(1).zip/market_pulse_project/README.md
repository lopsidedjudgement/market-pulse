
# Market Pulse - Multi-Agent System

This project demonstrates a multi-agent architecture using the Agent Development Kit (Python) to:
- Scrape market data
- Analyze insights via BigQuery
- Generate summarized reports
- Notify stakeholders in real-time

## Agents

- **ScraperAgent**: Pulls competitor/product data from public APIs
- **BigQueryAgent**: Retrieves historical market and sales data from Google BigQuery
- **AnalyzerAgent**: Applies NLP and sentiment models to identify trends and anomalies
- **ReporterAgent**: Compiles daily insights into visualized reports
- **NotifierAgent**: Sends real-time alerts via Slack or email

## Requirements

Install using:

```
pip install -r requirements.txt
```

## Running the Agents

Each agent can be run from its respective folder:

```
cd agents/AgentName
python agent.py
```

Example:

```
cd agents/ScraperAgent
python agent.py
```
