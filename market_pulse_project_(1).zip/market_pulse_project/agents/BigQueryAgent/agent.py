
import time
from utils.helper import log

def main():
    log("Starting BigQueryAgent...")
    time.sleep(2)
    log("BigQueryAgent finished processing.")

if __name__ == "__main__":
    main()
