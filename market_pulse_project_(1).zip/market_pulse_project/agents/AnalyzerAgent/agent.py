
import time
from utils.helper import log

def main():
    log("Starting AnalyzerAgent...")
    time.sleep(2)
    log("AnalyzerAgent finished processing.")

if __name__ == "__main__":
    main()
