
import time
from utils.helper import log

def main():
    log("Starting ReporterAgent...")
    time.sleep(2)
    log("ReporterAgent finished processing.")

if __name__ == "__main__":
    main()
