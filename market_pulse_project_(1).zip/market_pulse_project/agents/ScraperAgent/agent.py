
import time
from utils.helper import log

def main():
    log("Starting ScraperAgent...")
    time.sleep(2)
    log("ScraperAgent finished processing.")

if __name__ == "__main__":
    main()
