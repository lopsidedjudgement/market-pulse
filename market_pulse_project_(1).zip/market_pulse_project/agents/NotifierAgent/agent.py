
import time
from utils.helper import log

def main():
    log("Starting NotifierAgent...")
    time.sleep(2)
    log("NotifierAgent finished processing.")

if __name__ == "__main__":
    main()
